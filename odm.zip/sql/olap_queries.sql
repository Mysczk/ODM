-- 1. Počet transakcí za měsíc
SELECT t.Year, t.Month, COUNT(*) AS TransactionCount
FROM transaction_fact f
JOIN time_dim t ON f.TimeID = t.TimeID
GROUP BY t.Year, t.Month
ORDER BY t.Year, t.Month;

-- 2. Celkový obrat za jednotlivé roky
SELECT t.Year, SUM(f.TotalValue) AS TotalRevenue
FROM transaction_fact f
JOIN time_dim t ON f.TimeID = t.TimeID
GROUP BY t.Year
ORDER BY t.Year;

-- 3. Sezónnost: obrat podle kvartálu (opravena verze s FLOOR)
SELECT 
    t.Year, 
    FLOOR((CAST(t.Month AS INTEGER) - 1) / 3) + 1 AS Quarter,
    SUM(f.TotalValue) AS QuarterlyRevenue
FROM transaction_fact f
JOIN time_dim t ON f.TimeID = t.TimeID
GROUP BY t.Year, Quarter
ORDER BY t.Year, Quarter;




-- 4. Produkty s klesajícím prodejem mezi 2023 a 2024
WITH year_sales AS (
    SELECT
        p.ProductName,
        t.Year,
        SUM(f.Quantity) AS TotalSold
    FROM transaction_fact f
    JOIN product_dim p ON f.ProductID = p.ProductID
    JOIN time_dim t ON f.TimeID = t.TimeID
    GROUP BY p.ProductName, t.Year
)
SELECT y1.ProductName, y1.TotalSold AS Sold_2023, y2.TotalSold AS Sold_2024
FROM year_sales y1
JOIN year_sales y2 ON y1.ProductName = y2.ProductName
WHERE y1.Year = 2023 AND y2.Year = 2024 AND y1.TotalSold > y2.TotalSold;
